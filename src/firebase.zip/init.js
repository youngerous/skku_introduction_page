import firebase from 'firebase/app';
import firestore from 'firebase/firestore';

// Initialize Firebase
var config = {
  apiKey: "AIzaSyCtP_gFOWcchZDEylnMDMWqDKSX5Df_O98",
  authDomain: "skku-likelion.firebaseapp.com",
  databaseURL: "https://skku-likelion.firebaseio.com",
  projectId: "skku-likelion",
  storageBucket: "skku-likelion.appspot.com",
  messagingSenderId: "9870614896"
};
const firebaseApp = firebase.initializeApp(config);
firebaseApp.firestore().settings({timestampsInSnapshots: true});

export default firebaseApp.firestore();